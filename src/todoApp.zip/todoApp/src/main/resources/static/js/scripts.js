document.addEventListener("DOMContentLoaded", function () {
    const todoContainer = document.getElementById("todos");

    // Fetch todos from the server
    function fetchTodos() {
        fetch('/api/todos')
            .then(response => response.json())
            .then(data => {
                todoContainer.innerHTML = ""; // Clear existing todos
                data.forEach(todo => {
                    const todoElement = createTodoElement(todo);
                    todoContainer.appendChild(todoElement);
                });
            });
    }

    // Function to create todo element
    function createTodoElement(todo) {
        const todoElement = document.createElement('div');
        todoElement.classList.add("todo");
        todoElement.innerHTML = `
            <input type="checkbox" ${todo.completed ? 'checked' : ''} onchange="updateTodoStatus(${todo.id}, this)">
            <span class="title ${todo.completed ? 'completed' : ''}">${todo.title}</span>
            <button class="edit-button" onclick="editTodo(${todo.id}, '${todo.title}')">Edit</button>
            <button class="delete-button" onclick="deleteTodo(${todo.id})">Delete</button>
        `;
        return todoElement;
    }

    // Handle form submission to add a new todo
    document.getElementById("addTodoButton").addEventListener("click", function () {
        const titleInput = document.getElementById("todoTitle");
        const title = titleInput.value.trim();
        if (title !== "") {
            addTodoToServer(title);
            titleInput.value = ""; // Clear input field
        }
    });

    // Function to add a new todo to the server
    function addTodoToServer(title) {
        fetch('/api/todos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title: title, completed: false })
        })
        .then(response => {
            if (response.ok) {
                fetchTodos(); // Fetch todos again to refresh the list
            }
        });
    }

    // Function to update the status of a todo (complete/incomplete)
    function updateTodoStatus(id, checkbox) {
        const completed = checkbox.checked;
        fetch(`/api/todos/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ completed: completed })
        })
        .then(response => {
            if (!response.ok) {
                checkbox.checked = !completed; // Revert checkbox status if update fails
            }
            fetchTodos(); // Fetch todos again to refresh the list
        });
    }

    // Function to edit a todo
    function editTodo(id, title) {
        const newTitle = prompt("Edit todo:", title);
        if (newTitle !== null && newTitle.trim() !== "") {
            fetch(`/api/todos/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ title: newTitle.trim() })
            })
            .then(response => {
                if (response.ok) {
                    fetchTodos(); // Fetch todos again to refresh the list
                }
            });
        }
    }

    // Function to delete a todo
    function deleteTodo(id) {
        if (confirm("Are you sure you want to delete this todo?")) {
            fetch(`/api/todos/${id}`, {
                method: 'DELETE'
            })
            .then(response => {
                if (response.ok) {
                    fetchTodos(); // Fetch todos again to refresh the list
                }
            });
        }
    }

    // Fetch todos when the page loads
    fetchTodos();
});
