package com.aman.JPADemo.service;

import com.aman.JPADemo.dao.StudentRequest;
import com.aman.JPADemo.entity.Student;
import com.aman.JPADemo.repo.StudentRepo;
import com.aman.JPADemo.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImplementation implements StudentService {

    @Autowired
    StudentRepo studentRepo;

    @Override
    public List<Student> getAllStudentByCourse(String courseName) {
        return studentRepo.findByCourse(courseName);
    }

    @Override
    public Student saveStudentData(StudentRequest studentRequest) {
        return studentRepo.save(Utility.Mapper(studentRequest));
    }

    @Override
    public void deleteStudent(int id) {
        studentRepo.deleteById(id);
    }

    @Override
    public List<Student> getAllStudent() {
        return studentRepo.getAllStudentData();
    }
}

