package com.aman.JPADemo.controller;

import com.aman.JPADemo.dao.StudentRequest;
import com.aman.JPADemo.entity.Student;
import com.aman.JPADemo.service.StudentService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/std")
public class StudentController {

    @Autowired
    StudentService studentService;

    @GetMapping("/get/{courseName}")
    public List<Student> getStudentByCourse(@PathVariable String courseName) {
        List<Student> allStudentByCourse = studentService.getAllStudentByCourse(courseName );
        return allStudentByCourse;
    }

    @PostMapping("/save")
    public Student saveStudent(@RequestBody StudentRequest studentRequest){
        return studentService.saveStudentData(studentRequest);
    }

    @DeleteMapping("delete/{id}")
    public void deleteStudent(@PathVariable int id){
        studentService.deleteStudent(id);
    }

    @GetMapping("/get")
    public List<Student> getAllStudent() {
        List<Student> allStudent = studentService.getAllStudent();
        return allStudent;
    }
}
