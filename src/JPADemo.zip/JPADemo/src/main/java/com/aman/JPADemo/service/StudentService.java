package com.aman.JPADemo.service;

import com.aman.JPADemo.dao.StudentRequest;
import com.aman.JPADemo.entity.Student;

import java.util.List;

public interface StudentService {

    public List<Student> getAllStudentByCourse(String courseName);


    Student saveStudentData(StudentRequest studentRequest);

    void deleteStudent(int id);

    List<Student> getAllStudent();
}
